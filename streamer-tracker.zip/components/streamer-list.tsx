"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Skeleton } from "@/components/ui/skeleton"
import { getStreamers, refreshAllStreamers } from "@/lib/actions"

export default function StreamerList() {
  const [streamers, setStreamers] = useState<string[]>([])
  const [loading, setLoading] = useState(true)
  const [refreshing, setRefreshing] = useState(false)
  const router = useRouter()

  const loadStreamers = async () => {
    try {
      const data = await getStreamers()
      setStreamers(data)
    } catch (error) {
      console.error("Failed to load streamers:", error)
    } finally {
      setLoading(false)
    }
  }

  const handleRefresh = async () => {
    setRefreshing(true)
    try {
      await refreshAllStreamers()
      await loadStreamers()
      router.refresh()
    } catch (error) {
      console.error("Failed to refresh streamers:", error)
    } finally {
      setRefreshing(false)
    }
  }

  useEffect(() => {
    loadStreamers()

    // Set up auto-refresh every minute
    const intervalId = setInterval(() => {
      handleRefresh()
    }, 60000) // 60000 ms = 1 minute

    return () => clearInterval(intervalId)
  }, [])

  if (loading) {
    return (
      <div className="space-y-3">
        <Skeleton className="h-12 w-full" />
        <Skeleton className="h-12 w-full" />
        <Skeleton className="h-12 w-full" />
      </div>
    )
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-semibold">Streamers ({streamers.length})</h2>
        <Button variant="outline" onClick={handleRefresh} disabled={refreshing}>
          {refreshing ? "Refreshing..." : "Refresh Data"}
        </Button>
      </div>

      {streamers.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {streamers.map((streamer) => (
            <Link key={streamer} href={`/streamer/${encodeURIComponent(streamer)}`} className="block">
              <Card className="hover:bg-slate-50 transition-colors">
                <CardContent className="p-4">
                  <div className="font-medium">{streamer}</div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      ) : (
        <div className="text-center py-8">
          <p className="text-lg text-slate-500">No streamers added yet</p>
          <p className="text-sm text-slate-400">Add a streamer to get started</p>
        </div>
      )}
    </div>
  )
}
