"use client"

import Link from "next/link"
import { useState } from "react"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"

// Update the Ghost type to match the actual data structure
type Ghost = {
  name?: string
  total?: number
  // Add fallback properties in case the structure is different
  [key: string]: any
}

export default function GhostList({
  ghosts,
  streamerName,
}: {
  ghosts: Ghost[]
  streamerName: string
}) {
  const [search, setSearch] = useState("")

  // Safely get the name from the ghost object, handling different possible structures
  const getGhostName = (ghost: Ghost): string => {
    // If ghost is a string, return it directly
    if (typeof ghost === "string") return ghost

    // If ghost has a name property that's a string, use that
    if (ghost.name && typeof ghost.name === "string") return ghost.name

    // If ghost itself is an object with a different structure, try to find a string property
    // that might represent the name
    for (const key of Object.keys(ghost)) {
      if (typeof ghost[key] === "string") {
        return ghost[key]
      }
    }

    // If we can't find a string property, convert the whole object to a string
    return String(ghost)
  }

  // Safely get the total from the ghost object
  const getGhostTotal = (ghost: Ghost): number => {
    if (typeof ghost.total === "number") return ghost.total
    return 0
  }

  const filteredGhosts = ghosts.filter((ghost) => {
    const name = getGhostName(ghost)
    return name.toLowerCase().includes(search.toLowerCase())
  })

  return (
    <div className="space-y-4">
      <Input
        placeholder="Search ghosts..."
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        className="max-w-md"
      />

      {filteredGhosts.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {filteredGhosts.map((ghost, index) => {
            const ghostName = getGhostName(ghost)
            const total = getGhostTotal(ghost)

            return (
              <Link
                key={`${ghostName}-${index}`}
                href={`/streamer/${encodeURIComponent(streamerName)}/ghost/${encodeURIComponent(ghostName)}`}
                className="block"
              >
                <Card className="hover:bg-slate-50 transition-colors">
                  <CardContent className="p-4 flex justify-between items-center">
                    <div className="font-medium">{ghostName}</div>
                    <div className="text-sm text-slate-500">Matches: {total}</div>
                  </CardContent>
                </Card>
              </Link>
            )
          })}
        </div>
      ) : (
        <div className="text-center py-8">
          <p className="text-lg text-slate-500">No ghosts found</p>
        </div>
      )}
    </div>
  )
}
