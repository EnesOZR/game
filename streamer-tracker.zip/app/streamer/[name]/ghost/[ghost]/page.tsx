import Link from "next/link"
import { notFound } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { getCommonMatches } from "@/lib/actions"

export default async function GhostPage({
  params,
}: {
  params: { name: string; ghost: string }
}) {
  const streamerName = decodeURIComponent(params.name)
  const ghostName = decodeURIComponent(params.ghost)

  const commonMatches = await getCommonMatches(streamerName, ghostName)

  if (!commonMatches) {
    notFound()
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <Card className="w-full max-w-4xl mx-auto">
        <CardHeader className="bg-slate-800 text-white">
          <CardTitle className="text-2xl">Common Matches</CardTitle>
          <CardDescription className="text-slate-300">
            Streamer: {streamerName} | Ghost: {ghostName}
          </CardDescription>
        </CardHeader>
        <CardContent className="p-6">
          {commonMatches.length > 0 ? (
            <div className="space-y-4">
              <ul className="space-y-2">
                {commonMatches.map((match) => (
                  <li key={match} className="p-3 bg-slate-100 rounded hover:bg-slate-200">
                    <Link
                      href={`/streamer/${encodeURIComponent(streamerName)}/ghost/${encodeURIComponent(ghostName)}/match/${match}`}
                      className="block"
                    >
                      Match ID: {match}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ) : (
            <div className="text-center py-8">
              <p className="text-lg text-slate-500">No common matches found</p>
            </div>
          )}

          <div className="flex justify-end mt-6">
            <Link href={`/streamer/${encodeURIComponent(streamerName)}`}>
              <Button variant="outline">Back to Ghost List</Button>
            </Link>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
