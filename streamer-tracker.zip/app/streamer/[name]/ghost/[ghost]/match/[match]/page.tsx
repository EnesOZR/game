import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export default function MatchPage({
  params,
}: {
  params: { name: string; ghost: string; match: string }
}) {
  const streamerName = decodeURIComponent(params.name)
  const ghostName = decodeURIComponent(params.ghost)
  const matchId = params.match

  return (
    <div className="container mx-auto py-8 px-4">
      <Card className="w-full max-w-6xl mx-auto">
        <CardHeader className="bg-slate-800 text-white">
          <CardTitle className="text-2xl">Match Comparison</CardTitle>
          <CardDescription className="text-slate-300">
            Streamer: {streamerName} | Ghost: {ghostName} | Match: {matchId}
          </CardDescription>
        </CardHeader>
        <CardContent className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <h3 className="text-lg font-medium text-center">Streamer: {streamerName}</h3>
              <div className="aspect-video bg-slate-200 rounded overflow-hidden">
                <iframe
                  src={`https://pubg.sh/${streamerName}/steam/${matchId}`}
                  className="w-full h-full border-0"
                  title={`${streamerName}'s match replay`}
                  allowFullScreen
                />
              </div>
            </div>

            <div className="space-y-2">
              <h3 className="text-lg font-medium text-center">Ghost: {ghostName}</h3>
              <div className="aspect-video bg-slate-200 rounded overflow-hidden">
                <iframe
                  src={`https://pubg.sh/${ghostName}/steam/${matchId}`}
                  className="w-full h-full border-0"
                  title={`${ghostName}'s match replay`}
                  allowFullScreen
                />
              </div>
            </div>
          </div>

          <div className="flex justify-end mt-6">
            <Link href={`/streamer/${encodeURIComponent(streamerName)}/ghost/${encodeURIComponent(ghostName)}`}>
              <Button variant="outline">Back to Common Matches</Button>
            </Link>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
