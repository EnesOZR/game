import Link from "next/link"
import { notFound } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { getStreamerData, deleteStreamer } from "@/lib/actions"
import GhostList from "@/components/ghost-list"

export default async function StreamerPage({ params }: { params: { name: string } }) {
  const streamerName = decodeURIComponent(params.name)
  const streamerData = await getStreamerData(streamerName)

  if (!streamerData) {
    notFound()
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <Card className="w-full max-w-4xl mx-auto">
        <CardHeader className="bg-slate-800 text-white">
          <div className="flex justify-between items-center">
            <div>
              <CardTitle className="text-2xl">{streamerName}</CardTitle>
              <CardDescription className="text-slate-300">
                Ghost List ({streamerData.length} potential stream snipers)
              </CardDescription>
            </div>
            <div className="flex gap-2">
              <form
                action={async () => {
                  "use server"
                  await deleteStreamer(streamerName)
                }}
              >
                <Button type="submit" variant="destructive">
                  Delete
                </Button>
              </form>
              <Link href="/">
                <Button variant="outline">Back</Button>
              </Link>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-6">
          <GhostList ghosts={streamerData} streamerName={streamerName} />
        </CardContent>
      </Card>
    </div>
  )
}
