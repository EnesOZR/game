import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import StreamerList from "@/components/streamer-list"

export default function Home() {
  return (
    <div className="container mx-auto py-8 px-4">
      <Card className="w-full max-w-4xl mx-auto">
        <CardHeader className="bg-slate-800 text-white">
          <CardTitle className="text-2xl">PUBG Streamer Tracker</CardTitle>
          <CardDescription className="text-slate-300">
            Track streamers and detect potential stream snipers
          </CardDescription>
        </CardHeader>
        <CardContent className="p-6">
          <div className="flex flex-col gap-6">
            <StreamerList />

            <div className="flex justify-between mt-4">
              <Link href="/add-streamer">
                <Button className="bg-green-600 hover:bg-green-700">Add New Streamer</Button>
              </Link>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
