"use server"

import fs from "fs/promises"
import path from "path"
import { cache } from "react"
import { revalidatePath } from "next/cache"

const DATA_FOLDER = path.join(process.cwd(), "data", "streamer")

// Ensure data directory exists
async function ensureDataDir() {
  try {
    await fs.mkdir(DATA_FOLDER, { recursive: true })
  } catch (error) {
    console.error("Failed to create data directory:", error)
  }
}

// Get list of all streamers
export const getStreamers = cache(async () => {
  await ensureDataDir()

  try {
    const files = await fs.readdir(DATA_FOLDER)
    return files.filter((file) => file.endsWith(".json")).map((file) => file.replace(".json", ""))
  } catch (error) {
    console.error("Failed to read streamers:", error)
    return []
  }
})

// Get streamer data
export async function getStreamerData(streamerName: string) {
  await ensureDataDir()

  try {
    const filePath = path.join(DATA_FOLDER, `${streamerName}.json`)
    const data = await fs.readFile(filePath, "utf-8")
    const parsedData = JSON.parse(data)

    // Ensure we're returning an array
    if (!Array.isArray(parsedData)) {
      console.warn(`Data for ${streamerName} is not an array, converting to array`)
      return [parsedData].filter(Boolean)
    }

    return parsedData
  } catch (error) {
    console.error(`Failed to read data for ${streamerName}:`, error)
    return null
  }
}

// Add a new streamer
export async function addStreamer(username: string) {
  await ensureDataDir()

  if (!username.trim()) {
    throw new Error("Username cannot be empty")
  }

  try {
    const response = await fetch("https://www.pubgumbra.com/src/api/names.php", {
      method: "POST",
      headers: {
        "User-Agent": "Mozilla/5.0",
        Origin: "https://www.pubgumbra.com",
        Referer: "https://www.pubgumbra.com/",
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: new URLSearchParams({ username }),
    })

    if (!response.ok) {
      throw new Error(`API request failed with status ${response.status}`)
    }

    const data = await response.json()

    if (!Array.isArray(data) || data.length === 0) {
      throw new Error("API returned empty or invalid data")
    }

    const filePath = path.join(DATA_FOLDER, `${username}.json`)
    await fs.writeFile(filePath, JSON.stringify(data, null, 2), "utf-8")

    revalidatePath("/")
    return { success: true }
  } catch (error) {
    console.error(`Failed to add streamer ${username}:`, error)
    throw error
  }
}

// Delete a streamer
export async function deleteStreamer(streamerName: string) {
  await ensureDataDir()

  try {
    const filePath = path.join(DATA_FOLDER, `${streamerName}.json`)
    await fs.unlink(filePath)
    revalidatePath("/")
    return { success: true }
  } catch (error) {
    console.error(`Failed to delete streamer ${streamerName}:`, error)
    throw error
  }
}

// Refresh data for a specific streamer
export async function refreshStreamer(streamerName: string) {
  return addStreamer(streamerName)
}

// Refresh all streamers
export async function refreshAllStreamers() {
  const streamers = await getStreamers()

  const results = await Promise.allSettled(streamers.map((streamer) => refreshStreamer(streamer)))

  const failures = results.filter((result): result is PromiseRejectedResult => result.status === "rejected")

  if (failures.length > 0) {
    console.error(`Failed to refresh ${failures.length} streamers`)
  }

  revalidatePath("/")
  return { success: true, total: streamers.length, failures: failures.length }
}

// Get common matches between streamer and ghost
export async function getCommonMatches(streamerName: string, ghostName: string) {
  try {
    // Fetch matches for streamer
    const streamerResponse = await fetch(`https://chickendinner.gg/api/matches?name=${streamerName}&region=steam`)
    if (!streamerResponse.ok) {
      throw new Error(`Failed to fetch matches for ${streamerName}`)
    }
    const streamerData = await streamerResponse.json()
    const streamerMatches = streamerData.matches || []

    // Fetch matches for ghost
    const ghostResponse = await fetch(`https://chickendinner.gg/api/matches?name=${ghostName}&region=steam`)
    if (!ghostResponse.ok) {
      throw new Error(`Failed to fetch matches for ${ghostName}`)
    }
    const ghostData = await ghostResponse.json()
    const ghostMatches = ghostData.matches || []

    // Find common matches
    const commonMatches = streamerMatches.filter((match) => ghostMatches.includes(match))

    return commonMatches
  } catch (error) {
    console.error(`Failed to get common matches:`, error)
    return []
  }
}
